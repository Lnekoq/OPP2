﻿using System.Collections;
using System.Collections.Generic;

namespace Lab4
{
    /// <summary>
    /// Container node class
    /// </summary>
    public sealed class NodeList : IEnumerable<Exhibit>
    {
        Node start;
        Node end;
        Node SS;
        public NodeList()
        {
            start = null;
            end = null;
            SS = null;
        }
        /// <summary>
        /// Moves to the first data node
        /// </summary>
        public void Start()
        {
            SS = start;
        }
        /// <summary>
        /// Moves to the next data node
        /// </summary>
        public void Next()
        {
            SS = SS.Next;
        }
        /// <summary>
        /// Checks whether the current data node is null or not
        /// </summary>
        /// <returns>true if exists, false otherwise</returns>
        public bool Exists()
        {
            return SS != null;
        }
        /// <summary>
        /// Method to put data in reversed order
        /// </summary>
        /// <param name="info">information about player</param>
        public void PutDataR(Exhibit info)
        {
            Node d = new Node(info, null);
            d.Next = start;
            start = d;
        }
        /// <summary>
        /// Method to put data in direct order
        /// </summary>
        /// <param name="info">information about player</param>
        public void PutDataD(Exhibit info)
        {
            Node d = new Node(info, null);
            if (start == null)
            {
                start = d;
                end = d;
            }
            else
            {
                end.Next = d;
                end = d;
            }
        }
        /// <summary>
        /// Method to remove exhibits whose get year and cost more than provided
        /// </summary>
        /// <param name="exhibit">exhibit's information whose age matches user's provided 
        /// one</param>
        public void RemoveExhibit(Exhibit exhibit)
        {
            Node before = FindExhibitBeforeRemoval(exhibit);

            if (before == null)
            {
                // If the exhibit to remove is at the start of the list
                start = start.Next;
            }
            else
            {
                before.Next = before.Next.Next;
            }
        }
        /// <summary>
        /// Method to find a exhibit who is before our needed to remove exhibit in list
        /// </summary>
        /// <param name="removal">exhibit to be removed</param>
        /// <returns></returns>
        private Node FindExhibitBeforeRemoval(Exhibit removal)
        {
            Node before = null;
            Node d = start;
            while (d.Data != removal)
            {
                before = d;
                d = d.Next;
            }
            return before;
        }
        /// <summary>
        /// Method to insert exhibit into a sorted list
        /// </summary>
        /// <param name="exhibit">exhibit to be inserted</param>
        public void InsertExhibit(Exhibit exhibit)
        {
            Node insert = new Node(exhibit, null);
            if (start is null)
            {
                start = insert;
            }
            else
            {
                if (exhibit <= start.Data)
                {
                    insert.Next = start;
                    start = insert;
                }
                else
                {
                    Node after = FindExhibitToInsterAfter(exhibit);
                    insert.Next = after.Next;
                    after.Next = insert;
                }
            }
        }
        /// <summary>
        /// Method which finds exhibit who is after insertion exhibit
        /// </summary>
        /// <param name="insert">exhibit to be inserted</param>
        /// <returns>exhibit who is after insertion exhibit</returns>
        private Node FindExhibitToInsterAfter(Exhibit insert)
        {
            Node after = start;
            while (after != null && after.Next != null && insert >= after.Next.Data)
            {
                after = after.Next;
            }
            return after;
        }
        /// <summary>
        /// Bubble sort method to sort exhibit by their age ascending and name alphabetically
        /// </summary>
        public void BubbleSort()
        {
            if (start == null)
            {
                return;
            }
            bool exists = true;
            while (exists)
            {
                exists = false;
                Node node = start;
                while (node != null && node.Next != null)
                {
                    if (node.Data <= node.Next.Data)
                    {
                        exists = true;
                        Exhibit temp = node.Data;
                        node.Data = node.Next.Data;
                        node.Next.Data = temp;
                    }
                    node = node.Next;
                }
            }
        }
        /// <summary>
        /// Method to walk through every exhibit in our list
        /// </summary>
        /// <returns>every exhibit in node list</returns>
        public IEnumerator<Exhibit> GetEnumerator()
        {
            for (Node d = start; d != null; d = d.Next)
            {
                yield return d.Data;
            }
        }
        /// <summary>
        /// Interface that allows us to iterate over a collection
        /// </summary>
        /// <returns>iterator to move through our list</returns>
        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

    }
}
