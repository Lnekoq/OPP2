﻿namespace Lab4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.actionStatusLabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.getYear = new System.Windows.Forms.TextBox();
            this.getCost = new System.Windows.Forms.TextBox();
            this.enterR = new System.Windows.Forms.TextBox();
            this.enterM = new System.Windows.Forms.TextBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.InputToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.PrintToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.InputNewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.skaičiavimaiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SortToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.RemoveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.IterpimasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // actionStatusLabel
            // 
            this.actionStatusLabel.AutoSize = true;
            this.actionStatusLabel.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Bold);
            this.actionStatusLabel.Location = new System.Drawing.Point(358, 343);
            this.actionStatusLabel.Name = "actionStatusLabel";
            this.actionStatusLabel.Size = new System.Drawing.Size(126, 14);
            this.actionStatusLabel.TabIndex = 26;
            this.actionStatusLabel.Text = "Atliktas veiksmas";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(342, 381);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(168, 14);
            this.label2.TabIndex = 25;
            this.label2.Text = "Tinkami eksponatai mok1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(342, 414);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(168, 14);
            this.label1.TabIndex = 24;
            this.label1.Text = "Tinkami eksponatai mok2";
            // 
            // getYear
            // 
            this.getYear.Font = new System.Drawing.Font("Consolas", 8F, System.Drawing.FontStyle.Bold);
            this.getYear.Location = new System.Drawing.Point(575, 361);
            this.getYear.Margin = new System.Windows.Forms.Padding(4);
            this.getYear.Name = "getYear";
            this.getYear.Size = new System.Drawing.Size(212, 20);
            this.getYear.TabIndex = 23;
            this.getYear.Text = "Įrašykite įsigijimo metus";
            // 
            // getCost
            // 
            this.getCost.Font = new System.Drawing.Font("Consolas", 8F, System.Drawing.FontStyle.Bold);
            this.getCost.Location = new System.Drawing.Point(576, 398);
            this.getCost.Margin = new System.Windows.Forms.Padding(4);
            this.getCost.Name = "getCost";
            this.getCost.Size = new System.Drawing.Size(212, 20);
            this.getCost.TabIndex = 22;
            this.getCost.Text = "Įrašykite įsigijimo kainą";
            // 
            // enterR
            // 
            this.enterR.Font = new System.Drawing.Font("Consolas", 8F, System.Drawing.FontStyle.Bold);
            this.enterR.Location = new System.Drawing.Point(12, 398);
            this.enterR.Margin = new System.Windows.Forms.Padding(4);
            this.enterR.Name = "enterR";
            this.enterR.Size = new System.Drawing.Size(226, 20);
            this.enterR.TabIndex = 21;
            this.enterR.Text = "Įrašykite pasirinktą rūšį";
            // 
            // enterM
            // 
            this.enterM.Font = new System.Drawing.Font("Consolas", 8F, System.Drawing.FontStyle.Bold);
            this.enterM.Location = new System.Drawing.Point(12, 361);
            this.enterM.Margin = new System.Windows.Forms.Padding(4);
            this.enterM.Name = "enterM";
            this.enterM.Size = new System.Drawing.Size(226, 20);
            this.enterM.TabIndex = 20;
            this.enterM.Text = "Įrašykite pasirinktus metus";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Bold);
            this.richTextBox1.Location = new System.Drawing.Point(12, 23);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(776, 299);
            this.richTextBox1.TabIndex = 19;
            this.richTextBox1.Text = "";
            // 
            // menuStrip2
            // 
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.skaičiavimaiToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip2.Size = new System.Drawing.Size(800, 24);
            this.menuStrip2.TabIndex = 27;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.InputToolStripMenuItem,
            this.PrintToolStripMenuItem,
            this.InputNewToolStripMenuItem,
            this.closeToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(48, 20);
            this.toolStripMenuItem1.Text = "Failas";
            // 
            // InputToolStripMenuItem
            // 
            this.InputToolStripMenuItem.Name = "InputToolStripMenuItem";
            this.InputToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.InputToolStripMenuItem.Text = "Įvesti pradinius duomenis";
            this.InputToolStripMenuItem.Click += new System.EventHandler(this.InputToolStripMenuItem_Click);
            // 
            // PrintToolStripMenuItem
            // 
            this.PrintToolStripMenuItem.Name = "PrintToolStripMenuItem";
            this.PrintToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.PrintToolStripMenuItem.Text = "Spausdinti";
            this.PrintToolStripMenuItem.Click += new System.EventHandler(this.PrintToolStripMenuItem_Click);
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.closeToolStripMenuItem.Text = "Baigti";
            // 
            // InputNewToolStripMenuItem
            // 
            this.InputNewToolStripMenuItem.Name = "InputNewToolStripMenuItem";
            this.InputNewToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.InputNewToolStripMenuItem.Text = "Įvesti naujus duomenis";
            this.InputNewToolStripMenuItem.Click += new System.EventHandler(this.InputNewToolStripMenuItem_Click);
            // 
            // skaičiavimaiToolStripMenuItem
            // 
            this.skaičiavimaiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SortToolStripMenuItem,
            this.RemoveToolStripMenuItem,
            this.IterpimasToolStripMenuItem});
            this.skaičiavimaiToolStripMenuItem.Name = "skaičiavimaiToolStripMenuItem";
            this.skaičiavimaiToolStripMenuItem.Size = new System.Drawing.Size(84, 20);
            this.skaičiavimaiToolStripMenuItem.Text = "Skaičiavimai";
            // 
            // SortToolStripMenuItem
            // 
            this.SortToolStripMenuItem.Name = "SortToolStripMenuItem";
            this.SortToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.SortToolStripMenuItem.Text = "Rikiavimas";
            this.SortToolStripMenuItem.Click += new System.EventHandler(this.SortToolStripMenuItem_Click);
            // 
            // RemoveToolStripMenuItem
            // 
            this.RemoveToolStripMenuItem.Name = "RemoveToolStripMenuItem";
            this.RemoveToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.RemoveToolStripMenuItem.Text = "Šalinimas";
            this.RemoveToolStripMenuItem.Click += new System.EventHandler(this.RemoveToolStripMenuItem_Click);
            // 
            // IterpimasToolStripMenuItem
            // 
            this.IterpimasToolStripMenuItem.Name = "IterpimasToolStripMenuItem";
            this.IterpimasToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.IterpimasToolStripMenuItem.Text = "Įterpimas";
            this.IterpimasToolStripMenuItem.Click += new System.EventHandler(this.IterpimasToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip2);
            this.Controls.Add(this.actionStatusLabel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.getYear);
            this.Controls.Add(this.getCost);
            this.Controls.Add(this.enterR);
            this.Controls.Add(this.enterM);
            this.Controls.Add(this.richTextBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label actionStatusLabel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox getYear;
        private System.Windows.Forms.TextBox getCost;
        private System.Windows.Forms.TextBox enterR;
        private System.Windows.Forms.TextBox enterM;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem InputToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem PrintToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem InputNewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem skaičiavimaiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem SortToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem RemoveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem IterpimasToolStripMenuItem;
    }
}

