﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;

namespace Lab4
{
    /// <summary>
    /// Node class
    /// </summary>
    public sealed class Node
    {
        public Exhibit Data { get; set; } //Exhibit's data
        public Node Next { get; set; }  //Address to next data

        /// <summary>
        /// Container to store exhibit's data and address to another data
        /// </summary>
        /// <param name="Data"></param>
        /// <param name="next"></param>
        public Node(Exhibit Data, Node next)
        {
            this.Data = Data;
            this.Next = next;
        }
    }
}
