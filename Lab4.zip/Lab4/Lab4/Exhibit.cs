﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Lab4
{
    /// <summary>
    /// class for exhibit data
    /// </summary>
    public class Exhibit
    {
        public string CatalogNr { get; private set; }
        public string Title { get; private set; }
        public string Type { get; private set; }
        public int Age { get; private set; }
        public int GetYear {  get; private set; }
        public double Cost {  get; private set; }
        /// <summary>
        /// method to put exhibit's data
        /// </summary>
        /// <param name="CatalogNr"></param>
        /// <param name="Title"></param>
        /// <param name="Type"></param>
        /// <param name="Age"></param>
        /// <param name="GetYear"></param>
        /// <param name="Cost"></param>
        public Exhibit(string CatalogNr, string Title, string Type, int Age, int GetYear, double Cost)
        {
            this.CatalogNr = CatalogNr;
            this.Title = Title;
            this.Type = Type;
            this.Age = Age;
            this.GetYear = GetYear;
            this.Cost = Cost;
        }
        /// <summary>
        /// Exhibit data in to string for printing
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            string line;
            line = String.Format("| {0,-10} | {1,8} | {2,10} | {3,3} | {4,11} | {5,8} |",
           CatalogNr, Title, Type, Age, GetYear, Cost);
            return line;
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        /// <summary>
        /// Overriden operator used to compare objects by their age and title
        /// </summary>
        /// <param name="a">First exhibit</param>
        /// <param name="b">Second exhibit</param>
        /// <returns></returns>
        public static bool operator >=(Exhibit a, Exhibit b)
        {
            int poz = String.Compare(a.Title, b.Title,
                                     StringComparison.CurrentCulture);
            return a.Age > b.Age || a.Age == b.Age && poz > 0;

        }
        /// <summary>
        /// Overriden operator used to compare objects by their age and title
        /// </summary>
        /// <param name="a">First exhibit</param>
        /// <param name="b">Second exhibit</param>
        /// <returns></returns>
        public static bool operator <=(Exhibit a, Exhibit b)
        {
            int poz = String.Compare(a.Title, b.Title,
                                     StringComparison.CurrentCulture);

            return a.Age < b.Age || a.Age == b.Age && poz < 0;
        }
        /// <summary>
        /// Method to print data into .csv file
        /// </summary>
        /// <returns></returns>
        public string CSVtoString()
        {
            string line;
            line = String.Format("{0,-10} ; {1,8} ; {2,10} ; {3,3} ; {4,11} ; {5,8} ", CatalogNr, Title, Type, Age, GetYear, Cost);
            return line;
        }
    }
}
