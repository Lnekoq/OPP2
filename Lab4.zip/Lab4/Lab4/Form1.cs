﻿using System;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Lab4
{
    public partial class Form1 : Form
    {
        NodeList exhibits1 = new NodeList();
        NodeList exhibits2 = new NodeList();

        NodeList exhibitsBoth = new NodeList();
        NodeList exhibitsNew = new NodeList();

        private int clickCount = 0;
        private string resultsFileName;
        private string schoolName1;
        private string schoolName2;
        private string schoolName3;

        const string Results = "..\\..\\Results.csv";
        const string Results_csv = "..\\..\\Data\\Results.txt";
        public Form1()
        {
            InitializeComponent();
            if (File.Exists(Results_csv))
            {
                File.Delete(Results_csv);
            }
            PrintToolStripMenuItem.Enabled = false;
            SortToolStripMenuItem.Enabled = false;
           // RemoveToolStripMenuItem.Enabled = false;
            InputNewToolStripMenuItem.Enabled = false;
            IterpimasToolStripMenuItem.Enabled = false;
        }
        /// <summary>
        /// Method to read data
        /// </summary>
        /// <param name="fd"></param>
        /// <param name="exhibits"></param>
        /// <param name="schoolname"></param>
        static void DataInput(string fd, NodeList exhibits, out string schoolname)
        {
            using (StreamReader rd = new StreamReader(fd))
            {
                string line;
                schoolname = rd.ReadLine();

                while ((line = rd.ReadLine()) != null)
                {
                    string[] parts = line.Split(';');
                    string catalogNr = parts[0];
                    string title = parts[1];
                    string type = parts[2];
                    int age = int.Parse(parts[3]);
                    int getYear = int.Parse(parts[4]);
                    double cost = double.Parse(parts[5]);
                    Exhibit exhibit = new Exhibit(catalogNr, title, type, age, getYear, cost);
                    exhibits.PutDataD(exhibit);
                }
            }
        }
        /// <summary>
        /// method to put exhibits that are set type and age
        /// </summary>
        /// <param name="exhibits">exhibits data</param>
        /// <param name="exhibitBoth">data with exhibits that are set type and age</param>
        /// <param name="R">set type</param>
        /// <param name="m">set age</param>
        static void NewCollection(NodeList exhibits, NodeList exhibitBoth, string R, int m)
        {
            foreach (var exhibit in exhibits)
            {
                if (exhibit.Age > m && exhibit.Type == R)
                {
                    Exhibit temp = new Exhibit(exhibit.CatalogNr, exhibit.Title, exhibit.Type, exhibit.Age, exhibit.GetYear, exhibit.Cost);
                    exhibitBoth.PutDataR(temp);
                }
            }
        }
        /// <summary>
        ///  method to count correct data by selected
        /// </summary>
        /// <param name="exhibits">data</param>
        /// <param name="m">set age</param>
        /// <param name="R">set type</param>
        /// <returns></returns>
        static int CountCorrect(NodeList exhibits, int m, string R)
        {
            int j = 0;
            foreach (var exhibit in exhibits)
            {
                if (exhibit.Age > m && exhibit.Type == R)
                {
                    j++;
                }
            }
            return j;
        }
        /// <summary>
        /// method to remove exhibits that are older and cost more than set 
        /// </summary>
        /// <param name="exhibitsBoth">data</param>
        /// <param name="year">set year</param>
        /// <param name="cost">set cost</param>
        static void Remove(NodeList exhibitsBoth, int year, double cost)
        {
            foreach (var exhibit in exhibitsBoth)
            {
                if (exhibit.GetYear > year && exhibit.Cost > cost)
                {
                    exhibitsBoth.RemoveExhibit(exhibit);
                }
            }
        }
        /// <summary>
        /// method to insert new exhibits
        /// </summary>
        /// <param name="exhibitsBoth"></param>
        /// <param name="exhibitsNew"></param>
        /// <param name="Type"></param>
        /// <param name="m"></param>
        static void Inserting(NodeList exhibitsBoth, NodeList exhibitsNew, string Type, int m)
        {
            foreach (var exhibit in exhibitsNew)
            {
                if (exhibit.Type == Type && exhibit.Age > m)
                {
                    exhibitsBoth.InsertExhibit(exhibit);
                }
            }
        }
        /// <summary>
        /// method to print data
        /// </summary>
        /// <param name="fv"></param>
        /// <param name="exhibits"></param>
        /// <param name="schoolName"></param>
        /// <param name="sentence"></param>
        static void Output(string fv, NodeList exhibits, string schoolName, string sentence)
        {
            string top =   "|------------|----------|------------|-----|-------------|----------|\n"
                         + "| Catalog Nr |  Title   |    Type    | Age | Bought Year |   Cost   |\n"
                         + "|------------|----------|------------|-----|-------------|----------|";
            using (var fr = File.AppendText(fv))
            {
                if (!exhibits.Exists())
                {
                    fr.WriteLine(sentence);
                    if (schoolName != null)
                    {
                        fr.WriteLine("|------------------------------|\n"
                        + "| School name: {0,15} |\n"
                        + "|------------------------------|",
                        schoolName);
                        fr.WriteLine(top);
                        foreach (var exhibit in exhibits)
                        {
                            fr.WriteLine("{0}", exhibit.ToString());
                        }
                        fr.WriteLine("|------------|----------|------------|-----|-------------|----------| ");
                    }
                    else
                    {
                        fr.WriteLine(top);
                        foreach (var exhibit in exhibits)
                        {
                            fr.WriteLine("{0}", exhibit.ToString());
                        }
                        fr.WriteLine("|------------|----------|------------|-----|-------------|----------| ");
                    }
                }
                else
                {
                    fr.WriteLine("|----------------------------------------|\n"
                    + "| School name: {0,-15} |\n"
                    + "| This school does not have any exhibits!|\n"
                    + "|----------------------------------------|",
                    schoolName);
                    fr.WriteLine("|----------------------------------------|\n"
                     + "| There are no exhibits! |\n"
                     + "|----------------------------------------|\n");
                }
            }
        }

        /// <summary>
        /// method to count how many exhibits in a list
        /// </summary>
        /// <param name="exhibits"></param>
        /// <returns></returns>
        static int ExhibitCount(NodeList exhibits)
        {
            int exhibitCount = 0;
            while (exhibits.Exists())
            {
                exhibitCount++;
                exhibits.Next();
            }
            return exhibitCount;
        }

        /// <summary>
        /// method to print data to csv
        /// </summary>
        /// <param name="fv"></param>
        /// <param name="exhibits"></param>
        static void PrintInToExel(string fv, NodeList exhibits)
        {
            using (var fr = File.AppendText(fv))
            {

                foreach (var exhibit in exhibits)
                {
                    fr.WriteLine("{0}", exhibit.CSVtoString());
                }
            }
        }
        private void BaigtiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void InputToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Title = "Pasirinkite duomenų failą";
            openFileDialog.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            DialogResult result = openFileDialog.ShowDialog();
            if (clickCount == 0)
            {
                if (result == DialogResult.OK)
                {
                    richTextBox1.Clear();
                    string filePath = openFileDialog.FileName;
                    string fileName = Path.GetFileName(filePath);
                    DataInput(filePath, exhibits1, out schoolName1);
                    richTextBox1.LoadFile(filePath, RichTextBoxStreamType.PlainText);
                    actionStatusLabel.Text = "Įvesti " + fileName + " failo duomenys";
                    clickCount++;
                }


            }
            else if (clickCount == 1)
            {
                if (result == DialogResult.OK)
                {
                    string temp = richTextBox1.Text;
                    string filePath = openFileDialog.FileName;
                    string fileName = Path.GetFileName(filePath);
                    DataInput(filePath, exhibits2, out schoolName2);
                    string fdata = File.ReadAllText(filePath, Encoding.UTF8);
                    richTextBox1.Text = temp + "\n" + "\n" + fdata;
                    actionStatusLabel.Text = "Įvesti " + fileName + " failo duomenys";
                }
                PrintToolStripMenuItem.Enabled = true;
                InputToolStripMenuItem.Enabled = false;
            }
        }

        private void PrintToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string R = enterR.Text.ToString();
            int m = int.Parse(enterM.Text.ToString());
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Title = "Išsaugokite failą";
            saveFileDialog.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            DialogResult result = saveFileDialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                richTextBox1.Clear();
                resultsFileName = saveFileDialog.FileName;
                if (File.Exists(resultsFileName))
                {
                    File.Delete(resultsFileName);
                }
                label2.Text = schoolName1 + " " + CountCorrect(exhibits1, m, R);
                label1.Text = schoolName2 + " " + CountCorrect(exhibits2, m, R);
                Output(resultsFileName, exhibits1, schoolName1, "");
                Output(resultsFileName, exhibits2, schoolName2, "");
                NewCollection(exhibits1, exhibitsBoth, R, m);
                NewCollection(exhibits2, exhibitsBoth, R, m);
                Output(resultsFileName, exhibitsBoth, null, "Results");

                richTextBox1.LoadFile(resultsFileName, RichTextBoxStreamType.PlainText);
                actionStatusLabel.Text = "Atspausdinti abiejų failų duomenys";
            }
            PrintToolStripMenuItem.Enabled = false;
            if (exhibitsBoth.Exists())
            {
                SortToolStripMenuItem.Enabled = false;
            }
            else
            {
                SortToolStripMenuItem.Enabled = true;
            }
        }

        private void SortToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            exhibitsBoth.BubbleSort();
            Output(resultsFileName, exhibitsBoth, null, "Results - (sorted)");
            string res = File.ReadAllText(resultsFileName, Encoding.UTF8);
            richTextBox1.AppendText(res);
            richTextBox1.ScrollToCaret();
            SortToolStripMenuItem.Enabled = false;
            RemoveToolStripMenuItem.Enabled = true;
            actionStatusLabel.Text = "Surikiuoti duomenys";
        }

        private void RemoveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            string line = getYear.Text.ToString();
            string line2 = getCost.Text.ToString();
            int exhibitCountBefore;
            int exhibitCountAfter;

            exhibitsBoth.Start();
            exhibitCountBefore = ExhibitCount(exhibitsBoth);

            
            if (int.TryParse(line, out int get_Year) && double.TryParse(line2, out double get_Cost))
            {
                Remove(exhibitsBoth,get_Year,get_Cost);
                exhibitsBoth.Start();
                exhibitCountAfter = ExhibitCount(exhibitsBoth);
            }
            else
            {
                MessageBox.Show("Netinkami duomenys");
                return;
            }
            if (exhibitCountBefore == exhibitCountAfter)
            {
                MessageBox.Show("Jokie eksponatai nebuvo pašalinti");
                return;
            }
            richTextBox1.Clear();
            if (exhibitCountAfter < exhibitCountBefore && exhibitCountAfter > 0)
            {
                Output(resultsFileName, exhibitsBoth,null, "Resulst- (sorted) with removed exhibits");
                string res = File.ReadAllText(resultsFileName, Encoding.UTF8);
                richTextBox1.AppendText(res);
                richTextBox1.ScrollToCaret();
                RemoveToolStripMenuItem.Enabled = false;
                InputNewToolStripMenuItem.Enabled = true;
                actionStatusLabel.Text = "Panaikinti eksponatai";
            }
            if (exhibitCountAfter == 0)
            {
                string allRemoved = "All exhibits from results list have been removed!";
                using (var fr = File.AppendText(resultsFileName))
                {
                    fr.WriteLine(allRemoved);
                }
                string res = File.ReadAllText(resultsFileName, Encoding.UTF8);
                richTextBox1.AppendText(res);
                richTextBox1.ScrollToCaret();
                RemoveToolStripMenuItem.Enabled = false;
                actionStatusLabel.Text = "Panaikinti visi eksponatai";
            }
        }

        private void InputNewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Title = "Pasirinkite naujų žaidėjų sąrašą";
            openFileDialog.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            DialogResult result = openFileDialog.ShowDialog();
            if (result == DialogResult.OK)
            {

                string fileName = openFileDialog.FileName;
                DataInput(fileName, exhibitsNew, out schoolName3);
                Output(resultsFileName, exhibitsNew, schoolName3, "Results - sorted list with " +
                    "removed and added extra exhibits");
                string res = File.ReadAllText(resultsFileName, Encoding.UTF8);
                richTextBox1.AppendText(res);
                richTextBox1.ScrollToCaret();
                actionStatusLabel.Text = "Papildytas surikiuotas sąrašas";
                InputNewToolStripMenuItem.Enabled = false;
                IterpimasToolStripMenuItem.Enabled = true;
            }
        }

        private void IterpimasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string R = enterR.Text.ToString();
            int m = int.Parse(enterM.Text.ToString());

            int exhibitsCountBefore;
            int exhibitsCountAfter;

            exhibitsBoth.Start();
            exhibitsCountBefore = ExhibitCount(exhibitsBoth);

            richTextBox1.Clear();
            Inserting(exhibitsBoth, exhibitsNew, R, m);

            exhibitsBoth.Start();
            exhibitsCountAfter = ExhibitCount(exhibitsBoth);

            PrintInToExel(Results, exhibitsBoth);
            if (exhibitsCountAfter>exhibitsCountBefore)
            {
                Output(resultsFileName, exhibitsBoth, null, "Results - sorted list with " +
                    "removed and added extra exhibits");

                string res = File.ReadAllText(resultsFileName, Encoding.UTF8);
                richTextBox1.AppendText(res);
                richTextBox1.ScrollToCaret();
                IterpimasToolStripMenuItem.Enabled = false;
                actionStatusLabel.Text = "Papildytas surikiuotas sąrašas";
            }
            else if(exhibitsCountAfter == exhibitsCountBefore)
            {
                string noneAdded = "|-----------------------------------------|\n"
                                 + "| No exhibits had been added to the list! |\n"
                                 + "|-----------------------------------------|\n";
                using (var fr = File.AppendText(resultsFileName))
                {
                    fr.WriteLine(noneAdded);
                }
                string res = File.ReadAllText(resultsFileName, Encoding.UTF8);
                richTextBox1.AppendText(res);
                richTextBox1.ScrollToCaret();
                IterpimasToolStripMenuItem.Enabled = false;
            }
            
        }


    }
}


